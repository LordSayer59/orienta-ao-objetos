
import javax.swing.JOptionPane;


public class NotasAlunosOO {

 
    public static void main(String[] args) {
       Aluno aluno = new Aluno();
       aluno.nome="roberto";
       aluno.rgm=3050;
       aluno.nota1=Double.parseDouble(JOptionPane.showInputDialog("nota 1: "));
       aluno.nota2=Double.parseDouble(JOptionPane.showInputDialog("nota 2: "));
       double media=(aluno.nota1+aluno.nota2)/2;
       JOptionPane.showMessageDialog(null,
               "nome:  "+aluno.nome+
               "\nRGM: "+aluno.rgm+
               "\nNota 1:"+aluno.nota1+
               "\nNota 2:"+aluno.nota2+
               "\nMedia:" +media);
              if (media>=6){
                  JOptionPane.showMessageDialog(null,"Aluno Aprovado");
              }else{
              if (media <3){
                  JOptionPane.showMessageDialog(null,"Aluno Reprovado");
              }else
                  
                      }
    }
    
}
