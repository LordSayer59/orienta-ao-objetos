
public class Aluno {
    public String nome;
    public int rgm;
    public double nota1;
    public double nota2; 
}
