
package facuproject;

import javax.swing.JOptionPane;


public class Facuproject {
//este projeto irá entrar com o nome, a idade e o salario
    //de um funcionario e exibir esses dados
    
    
    public static void main(String[] args) {
 //declarar as variaveis
 Funcionarios func = new Funcionarios ();
 String nome;
 int idade;
 double salario;
    // entrada de valores
    nome = JOptionPane.showInputDialog("digite o nome: ");
    idade = Integer.parseInt(JOptionPane.showInputDialog("digite sua idade: "));
    salario = Double.parseDouble(JOptionPane.showInputDialog("Salario: "));

    func.nome_func=nome;
    func.idade_func=idade;
    func.salario_func=salario;
    //saida de valores
    JOptionPane.showMessageDialog(null,"nome da pessoa: "+nome+
            "\nsalario: "+salario+ "\nIdade: "+idade);
}
}                                                                                               