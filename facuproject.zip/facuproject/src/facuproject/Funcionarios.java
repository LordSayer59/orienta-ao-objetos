/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package facuproject;

/**
 *
 * @author autologon
 */
class Funcionarios {
    public String nome_func;
   public int idade_func;
   public double salario_func;
}
